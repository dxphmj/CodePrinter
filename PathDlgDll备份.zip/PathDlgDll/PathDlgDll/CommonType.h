#pragma once

enum AlignStyle
{
	AS_OVERLAPPED,
	AS_IMAGE_TOP_TEXT_BOTTOM,
	AS_IMAGE_LEFT_TEXT_RIGHT
};